import React from 'react';

const NotFound = ()=> {
   return(
    <div>
        <h1 className="text-center">Page Not Exist</h1>
        <h2 className="text-center">Error 404</h2>
    </div>
   );
}

export default NotFound