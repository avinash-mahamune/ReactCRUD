import React, { useState, useEffect } from "react";
import Card from './card'

import './ecommerece.css'

const Dashboard = () => {

  
    useEffect(() => {       
       
    }, []);



    return (
        <div className="container">          
           <Card />
        </div>

    )
}


export default Dashboard;