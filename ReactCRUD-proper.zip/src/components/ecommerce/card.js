import React, { useState, useEffect } from "react";

const Card = () => {

  
    useEffect(() => {       
       
    }, []);



    return (
        <div className="card-wrapper">          
           <div className="am-header">
                <h1>Product Name</h1>
           </div>
           <div className="am-card-body">

           </div>
           <div className="am-footer">
            
           </div>
        </div>

    )
}


export default Card;